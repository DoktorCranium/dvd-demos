
    This is a binary version of OS Demos for DVK workstation,
    using SIMH simulator. To start it, run demos.sh (on Linux)
    or demos.bat (on Windows).

    Username is "root", no password.

    To halt a system cleanly, use command "reboot -h".
    ___
    Best wishes,
    Serge Vakulenko
    2011-04-20
