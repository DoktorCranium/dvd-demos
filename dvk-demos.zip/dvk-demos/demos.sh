#!/bin/sh

./pdp11 -i demos.ini
